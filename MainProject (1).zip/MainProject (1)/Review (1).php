<!DOCTYPE html>
<html>
<head>
  <title>Multiple Choice Quiz Results</title>
  <link href='https://fonts.googleapis.com/css?family=Press+Start+2P' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Quintessential' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Nova+Square' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<nav class="navbar navbar-fixed-top" id="top-nav">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" style="font-family: sans-serif" href="#">CAMPUS RECRUITMENT MANAGEMENT SYSTEM</a>
				</div>
				<ul id="list1" class="nav navbar-nav">
				   <li class="active"><a href="studentdash.php">Home</a></li>
				   <li class="active"><a href="index.html">Logout</a></li>
				</ul>
			</div>
		</nav>
</head>

<body style="color: white;">
  <h1>Quiz Results</h1>
  <?php
    $score = 0;

    // Define the correct answers
    $correct_answers = array(
      'q1' => 'b', // Question 1: Correct answer is 'a'
      'q2' => 'c', // Question 2: Correct answer is 'c'
      'q3' => 'c',
      'q4' => 'c',
      'q5' => 'b',
      // Add more correct answers here for additional questions
    );

    // Check submitted answers and calculate the score
    foreach ($correct_answers as $question => $correct_answer) {
      if (isset($_POST[$question]) && $_POST[$question] === $correct_answer) {
        $score++;
      }
    }

    // Display the score
    echo "<b><p><h4>Your Score Is: $score out of " . count($correct_answers) . "</h4></p></b>";
  ?>
</body>
</html>
