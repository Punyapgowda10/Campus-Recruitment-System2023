<!DOCTYPE html>
<html>
<head>
  <title>Multiple Choice Quiz</title>
  <link href='https://fonts.googleapis.com/css?family=Press+Start+2P' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Quintessential' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Nova+Square' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<nav class="navbar navbar-fixed-top" id="top-nav">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" style="font-family: sans-serif" href="#">CAMPUS RECRUITMENT MANAGEMENT SYSTEM</a>
				</div>
				<ul id="list1" class="nav navbar-nav">
				   <li class="active"><a href="studentdash.php">Home</a></li>
				   <li class="active"><a href="index.html">Logout</a></li>
				</ul>
			</div>
		</nav>
</head>
<body>
  <h2 align="center" style="font-family:sans-serif">MULTIPLE CHOICE QUESTIONS</h2>
  <div class="well container-fluid text-center" id="main">
  <form action="Review.php" method="post">

    <b><p>Question 1: Frames from one LAN can be transmitted to another LAN via the device?</p></b>
    <input type="radio" name="q1" value="a"> a) Modem<br>
    <input type="radio" name="q1" value="b"> b) Bridge<br>
    <input type="radio" name="q1" value="c"> c) Router<br>

    <b><p>Question 2: What is the protocol is used between E-mail Servers?</p></b>
    <input type="radio" name="q2" value="a"> a) FTP<br>
    <input type="radio" name="q2" value="b"> b) SNMP<br>
    <input type="radio" name="q2" value="c"> c) SMTP<br>

	<b><p>Question3: Which of the following summation operations is performed onbits to check an erroretecting code?</p></b>
    <input type="radio" name="q3" value="a"> a) Codec<br>
    <input type="radio" name="q3" value="b"> b) Coder-Decoder<br>
    <input type="radio" name="q3" value="c"> c) Checksum<br>

	<b><p>Question 4: which of the followig sorting algorithms can be used to sort a random linked list with minimum time complexity?</p></b>
    <input type="radio" name="q4" value="a"> a) Insertion Sort<br>
    <input type="radio" name="q4" value="b"> b) Quick Sort<br>
    <input type="radio" name="q4" value="c"> c) Merge Sort<br>

	<b><p>Question 2: Which of the following is a linear data structure?</p></b>
    <input type="radio" name="q5" value="a"> a) AVL Trees<br>
    <input type="radio" name="q5" value="b"> b) Array<br>
    <input type="radio" name="q5" value="c"> c) Graphs<br>

    <!-- Add more questions here -->

    <input type="submit" value="Submit" onclick="alert('Questions are submitted')">
  </form>
</div>
</body>
</html>
