<!DOCTYPE html>
<html>
<head>
  <title>Multiple Choice Quiz</title>
  <link href='https://fonts.googleapis.com/css?family=Press+Start+2P' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Quintessential' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Nova+Square' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<nav class="navbar navbar-fixed-top" id="top-nav">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" style="font-family: sans-serif" href="#">CAMPUS RECRUITMENT MANAGEMENT SYSTEM</a>
				</div>
				<ul id="list1" class="nav navbar-nav">
				   <li class="active"><a href="studentdash.php">Home</a></li>
				   <li class="active"><a href="index.html">Logout</a></li>
				</ul>
			</div>
		</nav>
</head>
<body>
  <h2 align="center" style="font-family:sans-serif">MULTIPLE CHOICE QUESTIONS</h2>
  <div class="well container-fluid text-center" id="main">
  <form action="Review.php" method="post">
    <input type="submit" value="Submit" onclick="alert('Do you want to check marks of this student')">
  </form>
</div>
</body>
</html><?php
// Database configuration
$hostname = 'your_database_host';
$database = 'your_database_name';
$username = 'your_database_username';
$password = 'your_database_password';

// Connect to the database
$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);

// Retrieve company ID from user input
$companyId = $_POST['company_id']; // You can use POST or GET as per your design

// Query to retrieve student results for the specified company
$query = "SELECT students.name, results.result
          FROM students
          INNER JOIN results ON students.id = results.student_id
          WHERE results.company_id = :companyId";

$stmt = $db->prepare($query);
$stmt->bindParam(':companyId', $companyId, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Display the results
echo "<h2>Student Results for Company ID $companyId</h2>";
echo "<table>";
echo "<tr><th>Student Name</th><th>Result</th></tr>";

foreach ($results as $result) {
    echo "<tr><td>{$result['name']}</td><td>{$result['result']}</td></tr>";
}

echo "</table>";
?>
