<html>
	<head>

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="style1.css">
		<nav class="navbar navbar-fixed-top" id="top-nav">
			<div class="container-fluid">
				<div class="navbar-header">
					<a class="navbar-brand" href="#">Campus Recruitment System</a>
				</div>
				<ul id="list1" class="nav navbar-nav">
					<li class="active"><a href="companydash.php">Home</a></li>
				    <li class="active"><a href="index.html">Logout</a></li>
				</ul>
			</div>
		</nav>
	  </head>
	  <body>
	  
	  <?php
		session_start();
		$servername="localhost";
		$username="root";
		$password="";
		$dbname="project";

		$conn = new mysqli($servername,$username,$password,$dbname);

		if($conn->connect_error){
			die("Connection failed: ".$conn->connect_error);
		}

		
		

		if($_SERVER["REQUEST_METHOD"]=="POST"){
			$job_title=$_POST['job_title'];
			$salary=$_POST['salary'];
			$deadline=$_POST['deadline'];
			$bond=$_POST['bond'];
			$year=$_POST['year'];
			$cpiv=$_POST['cpiv'];
			$twvp=$_POST['12vp'];
			$tenvp=$_POST['10vp'];
			$branchv=$_POST['branchv'];
			$age=$_POST['age'];
			$degreev=$_POST['degreev'];
			$location=$_POST['location'];
			$job_id=$_POST['job_id'];

			/*echo $name . "<BR>";
			echo $email. "<BR>";
			echo $dob. "<BR>";
			echo $branch. "<BR>";
			echo $year. "<BR>";
			echo $cpi. "<BR>";
			echo $twp. "<BR>";
			echo $tenp. "<BR>";
			echo $pwd. "<BR>";
			echo $phone. "<BR>";
			echo $degree. "<BR>";*/
			
			$sql="INSERT into vacancy(company_name,job_title,salary,location,deadline,bond,age,degreev,branchv,cpiv,year,12vp,10vp,job_id) values(\"".$_SESSION['name']."\",\"".$job_title."\",".$salary.",\"".$location."\",\"".$deadline."\",".$bond.",".$age.",\"".$degreev."\",\"".$branchv."\",".$cpiv.",".$year.",".$twvp.",".$tenvp.",".$job_id." );";
			;
			
			if($conn->query($sql)===TRUE){
			$GLOBALS['conn']->close();
		echo "<SCRIPT type='text/javascript'> //not showing me this
								alert('Vacancy Created Succesfully!!');
								window.location.replace(\"companydash.php\");
							</SCRIPT>";
		}else{
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
			
			/*
			$GLOBALS['conn']->close();
			header('Location: company_dash.php ');
			echo '<script language="javascript">';
			echo 'alert("Vacancy succesfully created!")';
			echo '</script>';*/
		}
	  ?>
	  
		<div class=" container-fluid " id="dash" style="color:whitesmoke;">
		<h2>CREATE VACANCY</h2>
		<form action="vacancy.php" method="POST" enctype="multipart/form-data">
        <div class="container">
		   <h3>Job Details</h3>
           <hr>
           <ol>
          
		  <li><label for="jod_id"><b>Job ID:</b></label>
          <input type="number" placeholder=" " name="job_id" required></li><br>

		   <li><label for="job_title"><b>Job Title:</b></label>
           <input type="text" name="job_title" required></li><br>

          <li><label for="salary"><b>Salary:</b></label>
          <input type="decimal" placeholder="in LPA" style="color: black;" name="salary" required> </li><br>
	
		  <li><label for="location"><b>Location:</b></label>
          <input type="text" placeholder="Ex.Delhi" style="color: black;" name="location"></li><br>
		  
		  
	      <li><label for="deadline"><b>Deadline:</b></label>
          <input type="date" placeholder=" " name="deadline" style="color: black;"></li><br>
	
          <li><label for="bond"><b>Bond:</b></label>
          <input type="number" placeholder=" " name="bond"></li></tr><br>
	
	      <li><label for="10vp"><b>10th Percentage:</b></label>
          <input type="decimal" placeholder="Ex.85.5" style="color: black;" name="10vp"></li><br>
		  
		  <li><label for="12vp"><b>12th Percentage:</b></label>
          <input type="decimal" placeholder="Ex.85.5" style="color: black;" name="12vp"></li><br>
		  
		  <li><label for="year"><b>Passing out Year:</b></label>
          <input type="number" placeholder="Ex.2019" style="color: black;" name="year"></li><br>
		  
		  <li><label for="cpiv"><b>CPI:</b></label>
          <input type="decimal" placeholder="Enter minimum cpi required" style="color: black;" name="cpiv"></li><br>
		  
		  <li><label for="degreev"><b>Course:</b></label>
	      <select name="degreev" placeholder="Select" style="color: black;">
          <option label="btech">B.Tech</option>
		  <option label="btech">M.Tech</option>
		  <option label="be">B.E</option>
		  <option label="me">M.E</option>
		   <option label="bca">BCA</option>
          <option label="mca">MCA</option>
	      <option label="msc">MSC</option>
		  </select></li><br>
		  
		  <li><label for="branchv"><b>Branch:</b></label>
	      <select name="branchv" placeholder="Select" style="color: black;">
          <option label="cse">CSE</option>
          <option label="it">IT</option>
          <option label="ece">ECE</option>
	      <option label="mech">MECH</option>
	      <option label="eee">EEE</option>
	      <option label="civil">CIVIL</option>
	      </select></li><br>
		  
		  <li><label for="age"><b>Maximum age:</b></label>
          <input type="number" placeholder=" " name="age"></li><br>
		  
		  
		  </ol>
          <hr>
		<!--</div> -->
		<p><b>By creating an vacancy you agree to our </b><a href="#">Terms & Privacy</a>.</p>
           <button type="submit" class="registerbtn" style="color:black;">Create Vacancy</button>
		  
		</div>
	</form>
  <div class="container signin">
  <p>Already have an account? <a href="#">Sign in</a>.</p>
  </div>
		</div>
<style>
    .form-container {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    
    label {
      display: inline-block;
      width: 150px; /* Adjust this value to control the width of the labels */
      font-weight: bold;
    }
    
    input,
    textarea {
      width: 250px;
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
  </style>

	</body>
		<footer>
		<nav class="navbar navbar-footer" id="bottom-nav" style="width:110%">
			<div class="container-fluid">
				<div id="col1" >
					<ul id="blist1">
						<li><a href='#'>About Us</a></li>
						<li><a href='#'>FAQs</a></li>
						<li><a href='#'>Contact Us</a></li>
					</ul>
				</div>
				
				<div id="col2" >
					<ul id="blist1">
						<li><a href='#'>Privacy Policy</a></li>
						<li><a href='#'>Legal</a></li>
						<li><a href='#'>Work With Us</a></li>
					</ul>
				</div>
				
				<div id="col3" class=" container-fluid">
				
					<ul id="blist3" >
						<li><i class="fa fa-facebook fa-2x" ><a href='#'></a></i></li>
						<li><i class="fa fa-twitter fa-2x"><a href='#'></a></i></li>
						<li><i class="fa fa-instagram fa-2x"><a href='#'></a></i></li>
						<li><i class="fa fa-linkedin fa-2x"><a href='#'></a></i></li>
					</ul>
					<ul>
					<!--<p id="lic">site design / logo (c) Company_Name Inc.<br> licensed under Company_Name inc. </p>-->
					<li id="blist4">site design / logo (c) Company_Name Inc.<br> licensed under Company_Name inc.</li>
					</ul>
				</div>
			</div>
		</nav>
	</footer>
</html>