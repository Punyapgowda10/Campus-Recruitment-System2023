<!DOCTYPE html>
<html>
<head>

</head>
<body>

<?php
	
	$job_id= $_GET['job_id'];
	$s_mail= $_GET['s_mail'];
	
	$servername="localhost";
					$username="root";
					$password="";
					$dbname="project";
					
	$conn = new mysqli($servername,$username,$password,$dbname);
	if (!$conn) {
		die('Could not connect: ' . mysqli_error($conn));
	}

	$sql1="SELECT * FROM students WHERE email = '".$s_mail."'";
	$result1 = $conn->query($sql1);
	$row1 = $result1->fetch_assoc();

	$sql2="SELECT * FROM vacancy WHERE job_id = '".$job_id."'";
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	
	//Pending!
	//echo $row1['degree']." ".$row2['degree']." ".$row1['cpi']." ".$row2['cpi'] ." ". $row1['year']." ".$row2['year'] ." ". $row1['12p']." ".$row2['12p'] ." ". $row1['10p']." ".$row2['10p'] ;
	
	if($row1['degree']==$row2['degreev'])
		echo "Degree required ".$row2['degreev']." <img src=\"Images/Righttickmark.jpg\" height=\"20\" width=\"20\" ><BR>";
	else
		echo "Degree required ".$row2['degreev']." <img src=\"Images/crossmark.png\" height=\"20\" width=\"20\" ><BR>";
	
	if($row1['cpi']>=$row2['cpiv'])
		echo "CPI required greater than ".$row2['cpiv']." <img src=\"Images/Righttickmark.jpg\" height=\"20\" width=\"20\" ><BR>";
	else
		echo "CPI required greater than ".$row2['cpiv']." <img src=\"Images/crossmark.png\" height=\"20\" width=\"20\" ><BR>";
	
	if($row1['year']>=$row2['year'])
		echo "Year of passing required greater than ".$row2['year']." <img src=\"Images/Righttickmark.jpg\" height=\"20\" width=\"20\" ><BR>";
	else
		echo "Year of passing required greater than ".$row2['year']." <img src=\"Images/crossmark.png\" height=\"20\" width=\"20\" ><BR>";
	
	if($row1['12p']>=$row2['12vp'])
		echo "12th %age required greater than ".$row2['12vp']." <img src=\"Images/Righttickmark.jpg\" height=\"20\" width=\"20\" ><BR>";
	else
		echo "12th %age required greater than ".$row2['12vp']." <img src=\"Images/crossmark.png\" height=\"20\" width=\"20\" ><BR>";
	
	if($row1['10p']>=$row2['10vp'])
		echo "10th %age required greater than ".$row2['10vp']." <img src=\"Images/Righttickmark.jpg\" height=\"20\" width=\"20\" ><BR>";
	else
		echo "10th %age required greater than ".$row2['10vp']." <img src=\"Images/crossmark.png\" height=\"20\" width=\"20\" ><BR>";
	
	
	if($row1['degree']==$row2['degreev'] && $row1['cpi']>=$row2['cpiv'] && $row1['year']>=$row2['year'] && $row1['12p']>=$row2['12vp'] && $row1['10p']>=$row2['10vp']  ){
		echo "<H3>You're eligible!</H3><BR>";
		echo "<input type=\"button\" value=\"Apply\" onclick=\"apply_fun('".$job_id."','".$s_mail."','".$row2['company_name']."',this)\">";
	}else{
		echo "<H3>You're not eligible!</H3><BR>";
	}
?>
</body>
<footer>
</footer>
</html>