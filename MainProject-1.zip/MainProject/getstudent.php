<!DOCTYPE html>
<html>
<head>

</head>
<body>

<?php
session_start();
//$job_id = $_GET['job_id'];
$servername="localhost";
					$username="root";
					$password="";
					$dbname="project";
					
$conn = new mysqli($servername,$username,$password,$dbname);
if (!$conn) {
    die('Could not connect: ' . mysqli_error($conn));
}

//$sql="SELECT * FROM vacancy WHERE job_id = ".$job_id."";
$sql = "SELECT * FROM students as S,applications as A,vacancy as V where S.email=A.s_mail and A.job_id=V.job_id";
// $result = $conn->query($sql);



// echo "<div id=\"sapp\" class=\"table-responsive table-bordered\">            
// 				  <table class=\"table table-hover\">"; 
// 			while($row = $result->fetch_assoc()){	   
// 					echo"<tr>
// 				   <tr><th>Name</th><td>".$row['name']."</td></tr>
// 				   <tr><th>Email</th><td>".$row['email']."</td></tr>
// 				   <tr><th>DOB</th><td>".$row['dob']."</td></tr>
// 				   <tr><th>BRANCH</th><td>".$row['branch']."</td></tr>
// 				   <tr><th>YEAR</th><td>".$row['year']."</td></tr>
// 				   <tr><th>CPI</th><td>".$row['cpi']."</td></tr>
// 				   <tr><th>12th Percentage</th><td>".$row['12p']."</td></tr>
// 				   <tr><th>10th Percentage</th><td>".$row['10p']."</td></tr>
// 				   <tr><th>CONTACT NO.</th><td>".$row['phone']."</td></tr>
// 				   <tr><th>DEGREE</th><td>".$row['degree']."</td></tr>
// 				   <tr><th>Result</th><td><a href=\"Review.php\"><button type=\"submit\" style=\"border: 2px solid #515050;background-color:#ffd000; border-radius: 4px;\">Review Exam</button></a></td></tr>
// 				   </tr>";
// 			}		   
// 			echo	   "
// 				   </table>";
				   
				
				   
// 			echo "</div>";		




$result = $conn->query($sql);



echo "<div class=\"table-responsive table-bordered\" >            
				  <table class=\"table table-hover\">
				  <tr>
				   <th>Name</th>
				   <th>Email</th>
				   <th>DOB</th>
				   <th>Degree</th>
				   <th>Year</th>
				   <th>Phone</th>
				   <th>Branch</th>
				   <th>CPI</th>
				   <th>12th Percentage</th>
				   <th>10th Percentage</th>
				   </tr>
				   ";
			while($row = $result->fetch_assoc()){	   
					echo		   "
				   <tr>
				   <td>".$row['name']."</td>
				   <td>".$row['email']."</td>
				   <td>".$row['dob']."</td>
				   <td>".$row['degree']."</td>
				   <td>".$row['year']."</td>
				   <td>".$row['phone']."</td>
				   <td>".$row['branch']."</td>
				   <td>".$row['cpi']."</td>
				   <td>".$row['12p']."</td>
				   <td>".$row['10p']."</td>
				   </tr>";
			}		   
			echo	   "
				   </table>";
				   
				
				   
			echo "</div>";		

			


?>
</body>
</html>