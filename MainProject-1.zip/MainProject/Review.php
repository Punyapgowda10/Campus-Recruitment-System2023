<!DOCTYPE html>
<html>
<head>
  <title>Quiz Results</title>
</head>
<body>
  <h1>Quiz Results</h1>
  <?php
    $score = 0;

    // Define the correct answers
    $correct_answers = array(
      'q1' => 'a', // Question 1: Correct answer is 'a'
      'q2' => 'c', // Question 2: Correct answer is 'c'
      // Add more correct answers here for additional questions
    );

    // Check submitted answers and calculate the score
    foreach ($correct_answers as $question => $correct_answer) {
      if (isset($_POST[$question]) && $_POST[$question] === $correct_answer) {
        $score++;
      }
    }

    // Display the score
    echo "<p>This Student score: $score out of " . count($correct_answers) . "</p>";
  ?>
</body>
</html>
